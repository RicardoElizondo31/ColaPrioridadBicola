/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rick_
 */
public class colaBicola {
    protected valorPrioridad[] vector = new valorPrioridad[5];
    protected int ini;
    protected int fin;
    
    /*
    CONSTRUCTOR con 1 parametro para definir desde la ventana al tam vector
    */
    
    public colaBicola(int tam){
       for(int i=0; i<vector.length; i++){
            vector[i]=new valorPrioridad();
        }
    }
    
    public boolean insertarFin (valorPrioridad dato){
        if(fin==vector.length-1){
            return false;
        }
        if(ini==-1){
            ini=0;
        }
        fin++;
        vector[fin]=dato;
        Prioridad();
        return true;        
    }
    
    public boolean insertarIni (valorPrioridad dato){
        if(ini==0){
            return false;
        }
        if(ini==-1 && fin==-1){
            ini++;
            vector[ini]=dato;
            fin=0;
            return true;
        }
        ini--;
        vector[ini]=dato;
        Prioridad();
        return true;        
    }
    
    public boolean eliminarIni(){
        if(ini==-1 && fin==-1){
            return false;
        }
        if(ini==fin && ini!=1 && fin!=1){
            ini=-1;
            fin=-1;
            return true;
        }
        ini++;
        return true;
    }
    
    public boolean eliminarFin(){
        if(ini==-1 && fin==-1){
            return false;
        }
        if(ini==fin && ini!=1 && fin!=1){
            ini=-1;
            fin=-1;
            return true;
        }
        fin--;
        return true;
    }
    
     private void Prioridad(){
         int temporal;
        if(fin==0){
            return;
        }
        for(temporal=fin; temporal!=ini && vector[temporal].p>vector[temporal-1].p; temporal--){
            valorPrioridad cambio = new valorPrioridad();
            int anterior=temporal-1;
            
            cambio.v=vector[anterior].v;
            cambio.p=vector[anterior].p;
            
            vector[anterior].v=vector[temporal].v;
            vector[anterior].p=vector[temporal].p;
            
            vector[temporal].v=cambio.v;
            vector[temporal].p=cambio.p;
        }
    }
    
    protected boolean colaVacia(){
        return ini==-1 && fin==-1;
    }
    
    protected boolean unSoloDato(){
        return ini==fin;
    }
    
    public int getIni(){
        return ini;
    }
        
    public int getFin(){
        return fin;
    }

}
